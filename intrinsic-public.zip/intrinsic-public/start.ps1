$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Test-Python($candidate) {
    if (-not $candidate) { return $false }
    try {
        & $candidate -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" *> $null
        return ($LASTEXITCODE -eq 0)
    } catch {
        return $false
    }
}

$python = $null
if ($env:INTRINSIC_PYTHON) {
    if (Test-Python $env:INTRINSIC_PYTHON) { $python = $env:INTRINSIC_PYTHON }
}

if (-not $python) {
    $command = Get-Command python -ErrorAction SilentlyContinue
    if ($command -and (Test-Python $command.Source)) { $python = $command.Source }
}

if (-not $python) {
    $bundled = Join-Path $env:USERPROFILE ".dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
    if ((Test-Path $bundled) -and (Test-Python $bundled)) { $python = $bundled }
}

if (-not $python) {
    Write-Host ""
    Write-Host "Python 3.10+ was not found." -ForegroundColor Red
    Write-Host "Install Python from https://python.org, or set INTRINSIC_PYTHON to its full path."
    Write-Host ""
    exit 1
}

Write-Host ""
Write-Host "Starting Intrinsic..." -ForegroundColor Green
& $python (Join-Path $root "server.py") --open @args
